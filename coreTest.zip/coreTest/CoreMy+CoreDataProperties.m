//
//  CoreMy+CoreDataProperties.m
//  coreTest
//
//  Created by Derek on 2017/7/7.
//  Copyright © 2017年 Derek. All rights reserved.
//

#import "CoreMy+CoreDataProperties.h"

@implementation CoreMy (CoreDataProperties)

+ (NSFetchRequest<CoreMy *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"CoreMy"];
}

@dynamic title;
@dynamic detail;

@end

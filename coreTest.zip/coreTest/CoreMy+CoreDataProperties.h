//
//  CoreMy+CoreDataProperties.h
//  coreTest
//
//  Created by Derek on 2017/7/7.
//  Copyright © 2017年 Derek. All rights reserved.
//

#import "CoreMy+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface CoreMy (CoreDataProperties)

+ (NSFetchRequest<CoreMy *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *title;
@property (nullable, nonatomic, copy) NSString *detail;

@end

NS_ASSUME_NONNULL_END

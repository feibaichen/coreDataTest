//
//  ViewController.m
//  coreTest
//
//  Created by Derek on 2017/7/7.
//  Copyright © 2017年 Derek. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
#import "CoreMy+CoreDataClass.h"
@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong) AppDelegate *myAppDelegate;
@property (nonatomic,strong) UITableView *mytable;
@property (nonatomic,strong) NSMutableArray *dataArray;
@end

@implementation ViewController
-(void)viewWillAppear:(BOOL)animated{
    
    NSFetchRequest *FetchRequest=[[NSFetchRequest alloc]initWithEntityName:@"CoreMy"];
    
    NSError *error=nil;
    NSArray *temray=[self.myAppDelegate.persistentContainer.viewContext executeFetchRequest:FetchRequest error:&error];
    if (error) {
        NSLog(@"查询失败");
    }else{
        [self.dataArray addObjectsFromArray:temray];
    }


}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    _dataArray=[[NSMutableArray alloc]init];
    
    _mytable=[[UITableView alloc]initWithFrame:self.view.frame];
    _mytable.dataSource=self;
    _mytable.delegate=self;
    [self.view addSubview:_mytable];
    
    
    UIBarButtonItem *right=[[UIBarButtonItem alloc]initWithTitle:@"add" style:UIBarButtonItemStylePlain target:self action:@selector(add)];
    self.navigationItem.rightBarButtonItem=right;
    
    self.myAppDelegate=(AppDelegate *)[UIApplication sharedApplication].delegate;
    
}
//增加数据
-(void)add{
    NSEntityDescription *description=[NSEntityDescription entityForName:@"CoreMy" inManagedObjectContext:self.myAppDelegate.persistentContainer.viewContext];
    CoreMy *core=[[CoreMy alloc]initWithEntity:description insertIntoManagedObjectContext:self.myAppDelegate.persistentContainer.viewContext];
    core.title=@"zhangshan";
    core.detail=@"one great man,who change the world";
    [self.dataArray addObject:core];
    [self.mytable reloadData];
    [self.myAppDelegate saveContext];
}
//delete删除，左滑动
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle==UITableViewCellEditingStyleDelete) {
        CoreMy *c1=self.dataArray[indexPath.row];
        [self.dataArray removeObject:c1];
        [self.mytable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        
        [self.myAppDelegate.persistentContainer.viewContext deleteObject:c1];
        [self.myAppDelegate saveContext];
    }

}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cellid"];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cellid"];
    }
    CoreMy *c1=self.dataArray[indexPath.row];
    cell.textLabel.text=c1.title;
    cell.detailTextLabel.text=c1.detail;
    return cell;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

//
//  CoreMy+CoreDataClass.m
//  coreTest
//
//  Created by Derek on 2017/7/7.
//  Copyright © 2017年 Derek. All rights reserved.
//

#import "CoreMy+CoreDataClass.h"

@implementation CoreMy

@end

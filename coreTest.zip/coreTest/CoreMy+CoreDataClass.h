//
//  CoreMy+CoreDataClass.h
//  coreTest
//
//  Created by Derek on 2017/7/7.
//  Copyright © 2017年 Derek. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface CoreMy : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "CoreMy+CoreDataProperties.h"
